// beautify.js

// 1) Install js-beautify if you haven’t already:
//    npm install js-beautify

const fs       = require('fs');
const { html } = require('js-beautify');

// 2) Configure your input and output filenames:
const inputFile  = 'security.html';
const outputFile = 'security.html';

// 3) Load the raw HTML:
let src = fs.readFileSync(inputFile, 'utf8');

// 4) Beautify, forcing each attribute onto its own line:
let pretty = html(src, {
  indent_size: 2,                 // two-space indentation
  wrap_line_length: 0,            // no automatic wrapping
  wrap_attributes: 'force',       // one attribute per line
  wrap_attributes_indent_size: 2, // indent attributes by two spaces
  end_with_newline: true          // ensure file ends with a newline
});

// 5) Write out the beautified result to reg1.html:
fs.writeFileSync(outputFile, pretty, 'utf8');
console.log(`✅ Written beautified file: ${outputFile}`);
